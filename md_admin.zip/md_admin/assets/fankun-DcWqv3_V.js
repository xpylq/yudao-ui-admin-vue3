const s="/assets/fankun-CGGH57yF.png";export{s as default};
