const a="/assets/ganga-H-EkRHGS.png";export{a as default};
