import{_ as o}from"./FollowUpRecordBusinessForm.vue_vue_type_script_setup_true_lang-Dgc1XbAd.js";import"./index-D4mvcvXL.js";export{o as default};
