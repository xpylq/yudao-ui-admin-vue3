import{_ as t}from"./ProductAttributes.vue_vue_type_script_setup_true_lang-PMqcn_Sx.js";import"./index-D4mvcvXL.js";import"./property-0zebjbMM.js";export{t as default};
