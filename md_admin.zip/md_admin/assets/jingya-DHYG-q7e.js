const s="/assets/jingya-DsukK6zH.png";export{s as default};
