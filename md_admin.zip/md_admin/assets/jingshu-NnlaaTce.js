const s="/assets/jingshu-DJ4QZMd2.png";export{s as default};
