import{aG as s}from"./index-D4mvcvXL.js";const a=(t,r,o,f)=>`\uFFE5${s(o)}`;export{a as f};
