import{ct as u}from"./index-D4mvcvXL.js";const n=(t,l="default",r)=>{if(!t||!Reflect.has(t,l)||!u(t[l]))return null;const e=t[l];return e?e(r):null};export{n as g};
