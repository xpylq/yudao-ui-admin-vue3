import{az as a}from"./index-D4mvcvXL.js";const r=async()=>await a.get({url:"/trade/config/get"}),s=async t=>await a.put({url:"/trade/config/save",data:t});export{r as g,s};
