const s="/assets/xiong-CyH8wzVs.png";export{s as default};
