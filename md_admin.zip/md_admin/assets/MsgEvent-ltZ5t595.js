import{_ as o}from"./MsgEvent.vue_vue_type_script_setup_true_lang-Dri-VD4l.js";import"./index-D4mvcvXL.js";export{o as default};
