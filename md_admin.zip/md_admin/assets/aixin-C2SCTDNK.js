const s="/assets/aixin-UoJKe-pp.png";export{s as default};
