const s="/assets/yun-D6B6mboz.png";export{s as default};
