const s="/assets/shuizhuo-O_8EZ920.png";export{s as default};
