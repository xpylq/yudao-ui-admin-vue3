import{_ as o}from"./SaleOrderItemForm.vue_vue_type_script_setup_true_lang-AN6YYU-Q.js";import"./index-D4mvcvXL.js";import"./index-Wf0B3J2S.js";import"./index-BayUpdgv.js";export{o as default};
