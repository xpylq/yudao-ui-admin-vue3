import{_ as o}from"./main.vue_vue_type_script_setup_true_lang-dDFFJdy0.js";import"./index-D4mvcvXL.js";export{o as default};
