import{_ as o}from"./OtherForm.vue_vue_type_script_setup_true_lang-7rHcsMUb.js";import"./index-D4mvcvXL.js";import"./formRules-DRB1IpVO.js";export{o as default};
