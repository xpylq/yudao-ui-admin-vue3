const s="/assets/fennu-B7vTjwXu.png";export{s as default};
