import{_ as o}from"./Descriptions.vue_vue_type_style_index_0_scoped_30b8da63_lang-ZssqfbIx.js";import{B as a}from"./index-D4mvcvXL.js";const r=a(o,[["__scopeId","data-v-30b8da63"]]);export{r as _};
