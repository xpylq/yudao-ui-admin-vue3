const s="/assets/xinsui-DAcLsI5n.png";export{s as default};
