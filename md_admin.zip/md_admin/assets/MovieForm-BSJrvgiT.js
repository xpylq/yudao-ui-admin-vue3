import{_ as o}from"./MovieForm.vue_vue_type_script_setup_true_lang-Bmr0duKE.js";import"./index-D4mvcvXL.js";import"./Dialog.vue_vue_type_style_index_0_lang-CY6kwu13.js";export{o as default};
