const s="/assets/emo-D2PWQ3bk.png";export{s as default};
