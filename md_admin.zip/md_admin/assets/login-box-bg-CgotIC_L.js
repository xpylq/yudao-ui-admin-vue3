const s="/assets/login-box-bg-CL6i7T2F.svg";export{s as _};
