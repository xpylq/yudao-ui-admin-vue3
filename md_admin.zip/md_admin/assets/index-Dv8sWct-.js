import{az as a}from"./index-D4mvcvXL.js";const r=e=>a.get({url:"/mp/material/page",params:e}),t=e=>a.delete({url:"/mp/material/delete-permanent?id="+e});export{t as d,r as g};
