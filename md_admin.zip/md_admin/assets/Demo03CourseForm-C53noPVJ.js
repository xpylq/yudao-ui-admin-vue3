import{_ as o}from"./Demo03CourseForm.vue_vue_type_script_setup_true_lang-1uOfmyJb.js";import"./index-D4mvcvXL.js";import"./index-D16p8pyS.js";export{o as default};
